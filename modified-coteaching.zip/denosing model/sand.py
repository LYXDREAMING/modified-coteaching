import numpy as np
import torch
from torch.utils.data import Dataset
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
import argparse
from sklearn.preprocessing import StandardScaler
import pandas as pd
parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=1)
args = parser.parse_args()

class Sand(Dataset):
    def __init__(self, train_dataset = True,test_dataset = True,noise_type='unclearn'):

        names = ['no', 'c', 'fangle', 'L/D.s', 'a.s', 'x.s', 'h.s', 'langle.s', 'tk.s', 'f', 'p']
        data1 = pd.read_csv("numericalsand-554.csv", names=names)

        #data = load_boston()
        X1 = data1[names[1:9]]
        y1 = data1[names[10]]

        # Split dataset into train and test sets
        X_train_data, X_test, y_train, y_test = train_test_split(X1, y1, test_size=0.2, random_state=args.seed)
        X_train_data_indices = X_train_data.index.tolist()  # Get the indices of the test set samples
        print("Indices of samples in the train set:",X_train_data_indices)
        test_indices = X_test.index.tolist()  # Get the indices of the test set samples
        print("Indices of samples in the test set:",test_indices)
        # Standardize the features
        scaler = StandardScaler()
        X_train_data = scaler.fit_transform(X_train_data)
        X_test = scaler.transform(X_test)

        # Convert data to tensors
        X_train = torch.from_numpy(X_train_data).float()
        y_train_numpy = y_train.values
        y_train = torch.from_numpy(y_train_numpy).float().unsqueeze(1)

        X_test = torch.from_numpy(X_test).float()
        y_test_numpy = y_test.values
        y_test = torch.from_numpy(y_test_numpy).float().unsqueeze(1)


        self.train_dataset = train_dataset

        self.test_dataset = test_dataset

        self.dataset = 'numericalsand-554.csv'

        self.noise_type = noise_type

        if self.train_dataset:

            self.X_train = X_train
            self.y_train = y_train
            self.noise_or_not = np.transpose(self.y_train) == np.transpose(self.y_train)

        else:
            self.X_test = X_test
            self.y_test = y_test
            self.noise_or_not = np.transpose(self.y_test) == np.transpose(self.y_test)

    def __getitem__(self, index):
        if self.train_dataset:
            X = self.X_train[index]
            y = self.y_train[index]

        else:
            X = self.X_test[index]
            y = self.y_test[index]

        return X, y, index

    def __len__(self):
        if self.train_dataset:
            return len(self.X_train)

        else:
            return len(self.X_test)



class Sand2(Dataset):
    def __init__(self, all_dataset = True,noise_type='unclearn'):

        names = ['no', 'c', 'fangle', 'L/D.s', 'a.s', 'x.s', 'h.s', 'langle.s', 'tk.s', 'f', 'p']
        data1 = pd.read_csv("numericalsand-554.csv", names=names)
        data2 = pd.read_csv('numericalsand-554.csv',names=names)

        #data = load_boston()
        X1 = data1[names[1:9]]
        y1 = data1[names[10]]

        X_all = data2[names[1:9]]
        y_all = data2[names[10]]

        # Split dataset into train and test sets
        X_train_data, X_test, y_train, y_test = train_test_split(X1, y1, test_size=0.2, random_state=args.seed)

        # Standardize the features
        scaler = StandardScaler()
        X_train_data = scaler.fit_transform(X_train_data)
        X_all = scaler.transform(X_all)

        # Convert data to tensors

        X_all = torch.from_numpy(X_all).float()
        y_all = y_all.values
        y_all = torch.from_numpy(y_all).float().unsqueeze(1)

        self.all_dataset = all_dataset

        self.dataset = 'numericalsand-554.csv'

        self.noise_type = noise_type

        if self.all_dataset:

            self.X_all = X_all
            self.y_all = y_all
            self.noise_or_not = np.transpose(self.y_all) == np.transpose(self.y_all)

    def __getitem__(self, index):
        if self.all_dataset:
            X = self.X_all[index]
            y = self.y_all[index]

        return X, y, index

    def __len__(self):
        if self.all_dataset:
            return len(self.X_all)




