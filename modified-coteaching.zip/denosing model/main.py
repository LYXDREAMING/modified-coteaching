from __future__ import print_function
#import torch.utils.data as data
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import torchvision.transforms as transforms
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import argparse
import numpy as np
import datetime
import shutil
from sklearn.datasets import load_boston
import itertools
from loss4 import loss_coteaching
from loss4 import loss_coteaching1
from loss4 import loss_coteaching2
from torch.utils.data import TensorDataset
from torch.utils.data import Dataset
import codecs
import utils
import matplotlib.pyplot as plt
import errno
import os.path
import torch.optim as optim
from sand import Sand
from sand import Sand2
from model import Net
from model import build_model

parser = argparse.ArgumentParser()
parser.add_argument('--lr',type = float,default=0.005)
parser.add_argument('--result_dir',type=str,help='dir to save result txt files',default='results/')
parser.add_argument('--forget_rate', type = float, help = 'forget rate', default = 0.05)
parser.add_argument('--num_gradual', type = int, default = 10, help='how many epochs for linear drop rate, can be 5, 10, 15. This parameter is equal to Tk for R(T) in Co-teaching paper.')
parser.add_argument('--exponent', type = float, default = 1, help='exponent of the forget rate, can be 0.5, 1, 2. This parameter is equal to c in Tc for R(T) in Co-teaching paper.')
parser.add_argument('--top_bn', action='store_true')
parser.add_argument('--n_epoch', type=int, default=100)
parser.add_argument('--seed', type=int, default=1)
parser.add_argument('--print_freq', type=int, default=50)
parser.add_argument('--num_workers', type=int, default=4, help='how many subprocesses to use for data loading')
parser.add_argument('--num_iter_per_epoch', type=int, default=400)
parser.add_argument('--epoch_decay_start', type=int, default=80)
parser.add_argument('--dataset', type = str, help = 'sand', default = 'sand')
args = parser.parse_args()

# Seed 代码还使用torch.manual_seed()和torch.cuda.manual_seed()设置了随机种子，以保证实验的可复现性。
torch.manual_seed(args.seed)
torch.cuda.manual_seed(args.seed)

# Hyper Parameters
batch_size1 = 32
batch_size =32
learning_rate = args.lr

# Create result directory
if not os.path.exists(args.result_dir):
    os.makedirs(args.result_dir)
# 打开日志文件进行写入
log_file = os.path.join(args.result_dir, 'log.txt')
log = open(log_file, 'w', encoding='utf-8')

if args.dataset == 'sand':
    args.epoch_decay_start = 10 #表示衰减开始的轮数为80。
    args.n_epoch = 500 #表示训练的总轮数为200。
    train_dataset = Sand(train_dataset=True,test_dataset=False,noise_type='unclearn')
    test_dataset = Sand(train_dataset=False,test_dataset=True,noise_type='unclearn')
    all_dataset = Sand2(all_dataset=True,noise_type='unclearn')


if args.forget_rate is None:
    forget_rate = args.noise_rate
else:
    forget_rate = args.forget_rate

noise_or_not1 = train_dataset.noise_or_not
noise_or_not1 = noise_or_not1.squeeze()
noise_or_not2 = train_dataset.noise_or_not
noise_or_not2 = noise_or_not2.squeeze()


mom1 = 0.9
mom2 = 0.1
alpha_plan = [learning_rate] * args.n_epoch
beta1_plan = [mom1] * args.n_epoch

for i in range(args.epoch_decay_start, args.n_epoch):
    alpha_plan[i] = float(args.n_epoch - i) / (args.n_epoch - args.epoch_decay_start) * learning_rate
    beta1_plan[i] = mom2

def adjust_learning_rate(optimizer, epoch):
    for param_group in optimizer.param_groups:
        param_group['lr'] = alpha_plan[epoch]
        param_group['betas'] = (beta1_plan[epoch], 0.999)  # Only change beta1

# define drop rate schedule
rate_schedule = np.ones(args.n_epoch)*forget_rate
rate_schedule[:args.num_gradual] = np.linspace(0, forget_rate**args.exponent, args.num_gradual)

# Create result directory
if not os.path.exists(args.result_dir):
    os.makedirs(args.result_dir)
# 打开日志文件进行写入
log_file = os.path.join(args.result_dir, 'log.txt')
log = open(log_file, 'w', encoding='utf-8')

# Train and evaluate models
best_loss = float('inf')
best_epoch = 0

start_time = datetime.datetime.now()

start_time = datetime.datetime.now()

def index_value(output, y,threshold):

    ape = (torch.abs(y-output)/y)*100
    ape = ape.squeeze().cpu().detach().numpy()
    noise_or_not = ape <= threshold
    noise_or_not_tensor = torch.from_numpy(noise_or_not)

    return noise_or_not_tensor

def remove(predictions): #Remove less than 0
    for i in range(len(predictions)):
        if predictions[i] < 0:
            predictions[i]=0
    return predictions


def train(train_loader,epoch,model1,optimizer1,model2,optimizer2):
    selected_indices1=[]
    selected_indices2 = []
    ind_1_update_list = []
    ind_2_update_list = []
    ind_1_sorted_list = []
    ind_2_sorted_list = []
    loss_1_sorted_list = []
    loss_2_sorted_list = []

    for i,(X_batch,y_batch,index) in enumerate(train_loader):
        ind = index.cpu().numpy().transpose()
        if i>args.num_iter_per_epoch:#如果超过指定的每轮迭代次数，则跳出循环，结束该轮训练。
            break

        X_batch = X_batch.cuda()
        y_batch = y_batch.cuda()
        mean_y_true = torch.mean(y_batch)

        # Forward + Backward + Optimize
        output1= model1(X_batch)
        mape1 = torch.mean(torch.abs((y_batch-output1) / y_batch)) * 100.0
        mae1 = torch.mean(torch.abs(y_batch-output1))
        rmse1 = torch.sqrt(torch.mean((y_batch-output1)**2))
        R21 = 1-torch.sum((y_batch-output1)**2)/torch.sum((y_batch-mean_y_true)**2)

        output2 = model2(X_batch)
        mape2 = torch.mean(torch.abs((y_batch - output2) / y_batch)) * 100.0
        mae2 = torch.mean(torch.abs(y_batch-output2))
        rmse2 = torch.sqrt(torch.mean((y_batch-output2)**2))
        R22 = 1-torch.sum((y_batch-output2)**2)/torch.sum((y_batch-mean_y_true)**2)
        if epoch <=2000:

            noise_or_not_new1 = index_value(output1, y_batch, 25)
            true_results_1 = [result for result in noise_or_not_new1 if result]
            true_number_1 = len(true_results_1)
            noise_or_not1[ind] = noise_or_not_new1

            noise_or_not_new2 = index_value(output2, y_batch, 25)
            true_results_2 = [result for result in noise_or_not_new2 if result]
            true_number_2 = len(true_results_2)
            noise_or_not2[ind] = noise_or_not_new2
            if epoch <= 1000:

                loss_1, loss_2, pure_ratio_1, pure_ratio_2, ind_1_update, ind_2_update, \
                loss_1_sorted_update, loss_2_sorted_update,selected_indices1,selected_indices2 \
                    = loss_coteaching(output1, output2, y_batch, 0,
                                  ind, noise_or_not1, noise_or_not2, selected_indices1,selected_indices2)

            else :
                loss_1, loss_2, pure_ratio_1, pure_ratio_2, ind_1_update, ind_2_update, \
                loss_1_sorted_update, loss_2_sorted_update,selected_indices1,selected_indices2 \
                    = loss_coteaching2(output1, output2, y_batch, rate_schedule[epoch],
                                  ind, noise_or_not1, noise_or_not2, selected_indices1,selected_indices2)

        else:
            noise_or_not_new1 = index_value(output1, y_batch, 20)
            true_results_1 = [result for result in noise_or_not_new1 if result]
            true_number_1 = len(true_results_1)
            noise_or_not1[ind] = noise_or_not_new1

            noise_or_not_new2 = index_value(output2, y_batch, 20)
            true_results_2 = [result for result in noise_or_not_new2 if result]
            true_number_2 = len(true_results_2)
            noise_or_not2[ind] = noise_or_not_new2

            loss_1, loss_2, pure_ratio_1, pure_ratio_2, ind_1_update, ind_2_update,\
            loss_1_sorted_update, loss_2_sorted_update,selected_indices1,selected_indices2 \
                = loss_coteaching2(output1, output2, y_batch, rate_schedule[epoch],
                                  ind, noise_or_not1, noise_or_not2, selected_indices1,selected_indices2)

        ind_1_update_list.append(ind_1_update.cpu().numpy())
        ind_2_update_list.append(ind_2_update.cpu().numpy())
        #ind_1_sorted_list.append(ind_1_sorted.cpu().numpy())
        #ind_2_sorted_list.append(ind_2_sorted.cpu().numpy())
        loss_1_sorted_list.append(loss_1_sorted_update)
        loss_2_sorted_list.append(loss_2_sorted_update)

        #mape1.requires_grad = True
        optimizer1.zero_grad()
        loss_1.backward()
        optimizer1.step()
        optimizer2.zero_grad()
        loss_2.backward()
        optimizer2.step()
        np.save('ind_1_update.npy', np.array(ind_1_update_list))
        np.save('ind_2_update.npy', np.array(ind_2_update_list))
        np.save('loss_1_sorted.npy', np.array(loss_1_sorted_list))
        np.save('loss_2_sorted.npy', np.array(loss_2_sorted_list))


        if (i + 1) % args.print_freq == 0:
            print(
                'Epoch [%d/%d],Iter [%d/%d] mape1: %.4F%%, mape2: %.4f%%,'
                'mae1: %.4F, mae2: %.4f,'
                'rmse1: %.4F, rmse2: %.4f,'
                'R21: %.4F, R22: %.4f,'
                'Loss1: %.4f, Loss2: %.4f,'

                % ( epoch + 1, args.n_epoch,i+1, len(train_dataset) // batch_size1,float(mape1),float(mape2),
                    float(mae1),float(mae2),float(rmse1),float(rmse2),float(R21),float(R22)
                    , float(loss_1.data), float(loss_2.data),

                )
            )

    train_acc1 = float(true_number_1) / float(len(y_batch))  # 计算模型1的训练准确率。
    train_acc2 = float(true_number_2) / float(len(y_batch))  # 计算模型2的训练准确率。

    return mape1,mape2,mae1,mae2,rmse1,rmse2,R21,R22,train_acc1,train_acc2,selected_indices1,selected_indices2,\
           ind_1_update,ind_2_update,loss_1_sorted_update,loss_2_sorted_update

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
def evaluate(test_loader, model1, model2):
    #print('Evaluating %s...' % model_str)
    model1.eval()
    mape1 = 0
    total1 = 0
    for inputs,targets,_ in test_loader:
        inputs = inputs.to(device)
        targets =targets.to(device)
        mean_y_true = torch.mean(targets)

        outputs1 = model1(inputs)
        loss = nn.L1Loss()
        #mape1 = loss(outputs1,targets)
        mape1 = torch.mean(torch.abs((targets - outputs1) /targets)) * 100.0
        mae1 = torch.mean(torch.abs(targets-outputs1))
        rmse1 = torch.sqrt(torch.mean((targets-outputs1)**2))
        R21 = 1-torch.sum((targets-outputs1)**2)/torch.sum((targets-mean_y_true)**2)

    model2.eval()
    mape2 =0
    total2 =0
    for inputs,targets,_ in test_loader:
        inputs = inputs.to(device)
        targets =targets.to(device)
        outputs2 = model2(inputs)
        mean_y_true = torch.mean(targets)
        loss = nn.L1Loss()
        #mape2 = loss(outputs2, targets)
        mape2 = torch.mean(torch.abs((targets - outputs2) / targets)) * 100.0
        mae2 = torch.mean(torch.abs(targets-outputs2))
        rmse2 = torch.sqrt(torch.mean((targets-outputs2)**2))
        R22 = 1-torch.sum((targets-outputs2)**2)/torch.sum((targets-mean_y_true)**2)

    return mape1, mape2,mae1,mae2,rmse1,rmse2,R21,R22

def test_clean(test_loader, model1, model2):
    selected_indices1_test=[]
    selected_indices2_test = []
    model1.eval()
    mape1 = 0
    total1 = 0
    model2.eval()
    mape2 =0
    total2 =0
    for inputs,targets,index in test_loader:
        ind = index.cpu().numpy().transpose()
        inputs = inputs.to(device)
        targets =targets.to(device)

        outputs1 = model1(inputs)
        outputs2 = model2(inputs)

        noise_or_not_new1 = index_value(outputs1, targets, 20)
        true_results_1 = [result for result in noise_or_not_new1 if result]
        true_number_1 = len(true_results_1)
        noise_or_not1[ind] = noise_or_not_new1

        noise_or_not_new2 = index_value(outputs2, targets, 20)
        true_results_2 = [result for result in noise_or_not_new2 if result]
        true_number_2 = len(true_results_2)
        noise_or_not2[ind] = noise_or_not_new2

        loss_1, loss_2, pure_ratio_1, pure_ratio_2, ind_1_update, ind_2_update,\
        loss_1_sorted_update, loss_2_sorted_update, selected_indices1_test, selected_indices2_test \
            = loss_coteaching2(outputs1, outputs2, targets, 0.05,
                               ind, noise_or_not1, noise_or_not2, selected_indices1_test, selected_indices2_test)

    test_acc1 = float(true_number_1) / float(len(targets))  # 计算模型1的训练准确率。
    test_acc2 = float(true_number_2) / float(len(targets))  # 计算模型2的训练准确率。

    return test_acc1,test_acc2,selected_indices1_test,selected_indices2_test

def alldata_clean(all_loader, model1, model2):
    model1.eval()
    model2.eval()

    for X_all,y_all,index in all_loader:
        ind = index.cpu().numpy().transpose()

        X_all = X_all.to(device)
        y_all = y_all.to(device)
        mean_y_true = torch.mean(y_all)
        # 用model1 model2进行计算
        pre_y_all1 = model1(X_all)
        pre_y_all2 = model2(X_all)

        #model1误差结果
        mape1_all = torch.mean(torch.abs((y_all - pre_y_all1) /y_all)) * 100.0
        mae1_all = torch.mean(torch.abs(y_all - pre_y_all1))
        rmse1_all = torch.sqrt(torch.mean((y_all - pre_y_all1)**2))
        R21_all = 1-torch.sum((y_all - pre_y_all1)**2)/torch.sum((y_all-mean_y_true)**2)
        #model2误差结果
        mape2_all = torch.mean(torch.abs((y_all - pre_y_all2) /y_all)) * 100.0
        mae2_all = torch.mean(torch.abs(y_all - pre_y_all2))
        rmse2_all = torch.sqrt(torch.mean((y_all - pre_y_all2)**2))
        R22_all = 1-torch.sum((y_all - pre_y_all2)**2)/torch.sum((y_all-mean_y_true)**2)


    return mape1_all, mape2_all, mae1_all, mae2_all, rmse1_all, rmse2_all, R21_all, R22_all


def smooth_curve(points, window_size=10):
    # Create a window with equal weights
    window = np.ones(window_size) / window_size
    return np.convolve(points, window, mode='valid')

def main():
    # Data Loader (Input Pipeline)
    torch.autograd.set_detect_anomaly(True)

    print('loading dataset...')
    train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=batch_size1,drop_last = True,shuffle=True)
    test_loader = torch.utils.data.DataLoader(dataset=test_dataset,batch_size=batch_size,drop_last = True,shuffle=True)
    all_loader = torch.utils.data.DataLoader(dataset=all_dataset,batch_size=batch_size,drop_last = True,shuffle=True)
    # Define models
    print('building model...')

    input_size = 8
    model1 = build_model(input_size)
    model2 = build_model(input_size)
    model1.cuda()
    model2.cuda()

    # Define optimizer
    optimizer1 = torch.optim.RMSprop(model1.parameters(), lr=args.lr)
    optimizer2 = torch.optim.RMSprop(model2.parameters(), lr=args.lr)
    epoch=0

    # evaluate models with random weights
    test_mape1, test_mape2,test_mae1,test_mae2,test_rmse1,test_rmse2,test_R21,test_R22=evaluate(test_loader,model1, model2)

    print(
        'Epoch [%d/%d] Model1 Test Accuracy on the %s test mape:  %.4f %% , mae1: %.4f ,rmse1： %.4f ，R21 %.4f ' % (
            epoch + 1, args.n_epoch, len(test_dataset), test_mape1,test_mae1,test_rmse1,test_R21))
    print(
        'Epoch [%d/%d] Model2 Test Accuracy on the %s test mape:  %.4f %%, mae2: %.4f ,rmse2： %.4f ，R22 %.4f   ' % (
            epoch + 1, args.n_epoch, len(test_dataset), test_mape2,test_mae2,test_rmse2,test_R22))

    best_loss = float('inf')
    best_epoch = 0
    train_mae1_values = []
    test_mae1_values = []
    train_mae2_values = []
    test_mae2_values = []

    train_mape1_values = []
    test_mape1_values = []
    train_mape2_values = []
    test_mape2_values = []

    train_rmse1_values = []
    test_rmse1_values = []
    train_rmse2_values = []
    test_rmse2_values = []

    train_R21_values = []
    test_R21_values = []
    train_R22_values = []
    test_R22_values = []
    plot_interval = 50  # 设置每隔多少个epoch出一次图
    plot_counter = 0

    for epoch in range(1, args.n_epoch):
        # train models
        model1.train()
        adjust_learning_rate(optimizer1,epoch)
        model2.train()
        adjust_learning_rate(optimizer2,epoch)
        train_mape1, train_mape2,train_mae1,train_mae2,train_rmse1,train_rmse2,train_R21,train_R22,\
        train_acc1,train_acc2,selected_indices1,selected_indices2,ind_1_update,ind_2_update,loss_1_sorted,loss_2_sorted\
            = train(train_loader, epoch, model1, optimizer1, model2, optimizer2)
        test_mape1, test_mape2,test_mae1,test_mae2,test_rmse1,test_rmse2,test_R21,test_R22 = evaluate(test_loader, model1, model2)

        print(
            'Epoch [%d/%d],Iter [%d/%d] mape1: %.4F%%, mape2: %.4f%%,mae1: %.4F, mae2: %.4f,rmse1: %.4F, rmse2: %.4f,R21: %.4F, R22: %.4f,'
            'acc1: %.4f, acc2: %.4f,'
            % (epoch + 1, args.n_epoch, i + 1, len(train_dataset) // batch_size1, float(train_mape1), float(train_mape2),
               float(train_mae1), float(train_mae2), float(train_rmse1), float(train_rmse2), float(train_R21), float(train_R22)
               , float(train_acc1), float(train_acc2)))
        print(
            'Epoch [%d/%d] Model1 Test Accuracy on the %s test mape:  %.4f %% , mae1: %.4f ,rmse1： %.4f ，R21 %.4f ' % (
                epoch + 1, args.n_epoch, len(test_dataset), test_mape1, test_mae1, test_rmse1, test_R21))
        print(
            'Epoch [%d/%d] Model2 Test Accuracy on the %s test mape:  %.4f %%, mae2: %.4f ,rmse2： %.4f ，R22 %.4f   ' % (
                epoch + 1, args.n_epoch, len(test_dataset), test_mape2, test_mae2, test_rmse2, test_R22))


        # 用于保存每个epoch的train和test的MAE值

        # 记录train和test的MAE值
        train_mae1_values.append(train_mae1.cpu())  # 将train_mae1从GPU上移动到CPU上
        test_mae1_values.append(test_mae1.cpu())  # 假设test_mae1是test集的MAE值
        train_mae2_values.append(train_mae2.cpu())  # 将train_mae1从GPU上移动到CPU上
        test_mae2_values.append(test_mae2.cpu())  # 假设test_mae1是test集的MAE值

        train_mape1_values.append(train_mape1.cpu())  # 将train_mae1从GPU上移动到CPU上
        test_mape1_values.append(test_mape1.cpu())  # 假设test_mae1是test集的MAE值
        train_mape2_values.append(train_mape2.cpu())  # 将train_mae1从GPU上移动到CPU上
        test_mape2_values.append(test_mape2.cpu())  # 假设test_mae1是test集的MAE值

        train_rmse1_values.append(train_rmse1.cpu())  # 将train_mae1从GPU上移动到CPU上
        test_rmse1_values.append(test_rmse1.cpu())  # 假设test_mae1是test集的MAE值
        train_rmse2_values.append(train_rmse2.cpu())  # 将train_mae1从GPU上移动到CPU上
        test_rmse2_values.append(test_rmse2.cpu())  # 假设test_mae1是test集的MAE值

        train_R21_values.append(train_R21.cpu())  # 将train_mae1从GPU上移动到CPU上
        test_R21_values.append(test_R21.cpu())  # 假设test_mae1是test集的MAE值
        train_R22_values.append(train_R22.cpu())  # 将train_mae1从GPU上移动到CPU上
        test_R22_values.append(test_R22.cpu())  # 假设test_mae1是test集的MAE值

        # 绘制train和test集的MAE曲线
    epochs = list(range(1, args.n_epoch))
    # 用test的数据导入需要进行模型训练，用model和loss得到干净数据
    test_clean_test_acc1, test_clean_test_acc2, \
    test_clean_selected_indices1_test, test_clean_selected_indices2_test=test_clean(test_loader, model1, model2)
    print(
        'Epoch [%d/%d] Model2 Test Accuracy on the %s test clean acc1:  %.4f %%, test clean acc1: %.4f   ' % (
            epoch + 1, args.n_epoch, len(test_dataset), float(test_clean_test_acc1), float(test_clean_test_acc2)))

    mape1_all, mape2_all, mae1_all, mae2_all, rmse1_all, rmse2_all, R21_all, R22_all \
        = alldata_clean(all_loader, model1, model2)
    print(
        'Epoch [%d/%d] Model1 all Accuracy on the %s '
        'mape1: %.4F%%, mape2: %.4f%%,mae1: %.4F, mae2: %.4f,rmse1: %.4F, rmse2: %.4f,R21: %.4F, R22: %.4f, ' % (
            epoch + 1, args.n_epoch, len(all_dataset), float(mape1_all),
            float(mape2_all),
            float(mae1_all), float(mae2_all), float(rmse1_all), float(rmse2_all), float(R21_all),
            float(R22_all)))


    # 将Tensor对象转换为NumPy数组
    train_mae1_values_np = [train_mae1.detach().numpy() for train_mae1 in train_mae1_values]
    test_mae1_values_np = [test_mae1.detach().numpy() for test_mae1 in test_mae1_values]
    train_mae2_values_np = [train_mae2.detach().numpy() for train_mae2 in train_mae2_values]
    test_mae2_values_np = [test_mae2.detach().numpy() for test_mae2 in test_mae2_values]

    train_mape1_values_np = [train_mape1.detach().numpy() for train_mape1 in train_mape1_values]
    test_mape1_values_np = [test_mape1.detach().numpy() for test_mape1 in test_mape1_values]
    train_mape2_values_np = [train_mape2.detach().numpy() for train_mape2 in train_mape2_values]
    test_mape2_values_np = [test_mape2.detach().numpy() for test_mape2 in test_mape2_values]

    train_rmse1_values_np = [train_rmse1.detach().numpy() for train_rmse1 in train_rmse1_values]
    test_rmse1_values_np = [test_rmse1.detach().numpy() for test_rmse1 in test_rmse1_values]
    train_rmse2_values_np = [train_rmse2.detach().numpy() for train_rmse2 in train_rmse2_values]
    test_rmse2_values_np = [test_rmse2.detach().numpy() for test_rmse2 in test_rmse2_values]

    train_R21_values_np = [train_R21.detach().numpy() for train_R21 in train_R21_values]
    test_R21_values_np = [test_R21.detach().numpy() for test_R21 in test_R21_values]
    train_R22_values_np = [train_R22.detach().numpy() for train_R22 in train_R22_values]
    test_R22_values_np = [test_R22.detach().numpy() for test_R22 in test_R22_values]

    window_size=10
    plt.plot(epochs[window_size - 1:], smooth_curve(train_mae1_values_np, window_size=10), marker='o', linestyle='-',
             color='red', label='Smoothed Train MAE1')
    plt.plot(epochs[window_size - 1:], smooth_curve(test_mae1_values_np, window_size=10), marker='o', linestyle='-',
             color='black', label='Smoothed Test MAE1')
    plt.plot(epochs[window_size - 1:], smooth_curve(train_mae2_values_np, window_size=10), marker='o', linestyle='-',
             color='green', label='Smoothed Train MAE2')
    plt.plot(epochs[window_size - 1:], smooth_curve(test_mae2_values_np, window_size=10), marker='o', linestyle='-',
             color='yellow', label='Smoothed Test MAE2')

    plt.xlabel('Epoch')
    plt.ylabel('MAE')
    plt.title('Smoothed Train and Test MAE over Epochs')
    plt.grid(True)
    plt.legend()
    plt.show()

    plt.plot(epochs[window_size - 1:], smooth_curve(train_mape1_values_np, window_size=10), marker='o', linestyle='-',
             color='red', label='Smoothed Train MAPE1')
    plt.plot(epochs[window_size - 1:], smooth_curve(test_mape1_values_np, window_size=10), marker='o', linestyle='-',
             color='black', label='Smoothed Test MAPE1')
    plt.plot(epochs[window_size - 1:], smooth_curve(train_mape2_values_np, window_size=10), marker='o', linestyle='-',
             color='green', label='Smoothed Train MAPE2')
    plt.plot(epochs[window_size - 1:], smooth_curve(test_mape2_values_np, window_size=10), marker='o', linestyle='-',
             color='yellow', label='Smoothed Test MAPE2')

    plt.xlabel('Epoch')
    plt.ylabel('MAPE')
    plt.title('Smoothed Train and Test MAPE over Epochs')
    plt.grid(True)
    plt.legend()
    plt.show()

    plt.plot(epochs[window_size - 1:], smooth_curve(train_rmse1_values_np, window_size=10), marker='o', linestyle='-',
             color='red', label='Smoothed Train RMSE1')
    plt.plot(epochs[window_size - 1:], smooth_curve(test_rmse1_values_np, window_size=10), marker='o', linestyle='-',
             color='black', label='Smoothed Test RMSE1')
    plt.plot(epochs[window_size - 1:], smooth_curve(train_rmse2_values_np, window_size=10), marker='o', linestyle='-',
             color='green', label='Smoothed Train RMSE2')
    plt.plot(epochs[window_size - 1:], smooth_curve(test_rmse2_values_np, window_size=10), marker='o', linestyle='-',
             color='yellow', label='Smoothed Test RMSE2')

    plt.xlabel('Epoch')
    plt.ylabel('RMSE')
    plt.title('Smoothed Train and Test RMSE over Epochs')
    plt.grid(True)
    plt.legend()
    plt.show()

    plt.plot(epochs[window_size - 1:], smooth_curve(train_R21_values_np, window_size=10), marker='o', linestyle='-',
             color='red', label='Smoothed Train R21')
    plt.plot(epochs[window_size - 1:], smooth_curve(test_R21_values_np, window_size=10), marker='o', linestyle='-',
             color='black', label='Smoothed Test R21')
    plt.plot(epochs[window_size - 1:], smooth_curve(train_R22_values_np, window_size=10), marker='o', linestyle='-',
             color='green', label='Smoothed Train R22')
    plt.plot(epochs[window_size - 1:], smooth_curve(test_R22_values_np, window_size=10), marker='o', linestyle='-',
             color='yellow', label='Smoothed Test R22')

    plt.xlabel('Epoch')
    plt.ylabel('R2')
    plt.title('Smoothed Train and Test R2 over Epochs')
    plt.grid(True)
    plt.legend()
    plt.show()


    print('===================seleted==================')
    print(selected_indices1)
    print(selected_indices2)
    print(test_clean_selected_indices1_test)
    print(test_clean_selected_indices2_test)


if __name__ == '__main__':
    main()
